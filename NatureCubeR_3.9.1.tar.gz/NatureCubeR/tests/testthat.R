library(testthat)
library(NatureCubeR)

test_check("NatureCubeR")
