# Audits the phone-observation tree written by the procedure loop
# (~/Downloads/phone_observations by default). Checks each workbook against
# the files on disk and, when PROTECTEDFAUNA_API_KEY is set, against a fresh
# non-media pull so a short page cannot hide missing rows.

.phone_obs_export_root <- function() {
  path.expand(Sys.getenv(
    "PHONE_OBS_EXPORT_DIR",
    unset = "~/Downloads/phone_observations"
  ))
}

.phone_obs_read_sheet <- function(path, sheet) {
  readxl::read_excel(path, sheet = sheet, guess_max = 200000, .name_repair = "minimal")
}

.phone_obs_blank <- function(x) {
  x <- as.character(x)
  is.na(x) | !nzchar(trimws(x))
}

.phone_obs_audit_dir <- function(proc_dir) {
  problems <- character()
  note <- function(...) {
    problems <<- c(problems, paste0(basename(proc_dir), ": ", paste0(...)))
  }
  xlsx <- file.path(proc_dir, "observations.xlsx")
  if (!file.exists(xlsx)) {
    return(paste0(basename(proc_dir), ": missing observations.xlsx"))
  }
  sheets <- readxl::excel_sheets(xlsx)
  missing_sheets <- setdiff(
    c("Column description", "Wide format", "Long format"),
    sheets
  )
  if (length(missing_sheets)) {
    note("missing sheets ", paste(missing_sheets, collapse = ", "))
  }
  long <- .phone_obs_read_sheet(xlsx, "Long format")
  wide <- .phone_obs_read_sheet(xlsx, "Wide format")
  guide <- .phone_obs_read_sheet(xlsx, "Column description")

  if (nrow(long) == 0L) {
    media_files <- list.files(file.path(proc_dir, "media"))
    if (length(media_files)) {
      note("empty workbook but media files exist: ", paste(media_files, collapse = ", "))
    }
    return(problems)
  }

  required <- c("feature_uuid", "data_type", "item_name", "survey_observation")
  missing_cols <- setdiff(required, names(long))
  if (length(missing_cols)) {
    note("long format missing ", paste(missing_cols, collapse = ", "))
    return(problems)
  }
  dropped <- intersect(
    c("observation_id", "label_id", "project_id", "phone_model"),
    names(long)
  )
  if (length(dropped)) {
    note("noise columns still present: ", paste(dropped, collapse = ", "))
  }
  if (any(.phone_obs_blank(long$feature_uuid))) {
    note(sum(.phone_obs_blank(long$feature_uuid)), " rows without feature_uuid")
  }

  # Wide format is one row per feature and the column guide covers both sheets.
  features <- unique(long$feature_uuid[! .phone_obs_blank(long$feature_uuid)])
  if (!("feature_uuid" %in% names(wide)) || nrow(wide) != length(features)) {
    note(
      "wide rows ", nrow(wide), " != ", length(features), " features"
    )
  } else {
    missing_features <- setdiff(features, wide$feature_uuid)
    if (length(missing_features)) {
      note(length(missing_features), " features absent from the wide sheet")
    }
  }
  if (all(c("sheet name", "column") %in% names(guide))) {
    for (sheet in c("Wide format", "Long format")) {
      data <- if (sheet == "Wide format") wide else long
      undocumented <- setdiff(names(data), guide$column[guide$`sheet name` == sheet])
      if (length(undocumented)) {
        note(sheet, " columns missing from the guide: ", paste(undocumented, collapse = ", "))
      }
    }
  }

  # Every scientific name keeps a complete tree: genus and species always,
  # and any higher rank or common name known for that name on another row.
  if ("data_type" %in% names(long) && nrow(long) > 0L) {
    labels <- long[!is.na(long$data_type) & long$data_type == "label", , drop = FALSE]
    named <- labels[! .phone_obs_blank(labels$survey_observation), , drop = FALSE]
    if (nrow(named) > 0L) {
      ranks <- c("class", "order", "family", "genus", "species", "common_name")
      missing_cols <- setdiff(ranks, names(named))
      if (length(missing_cols)) {
        note("label rows have no columns ", paste(missing_cols, collapse = ", "))
      } else {
        for (name in unique(named$survey_observation)) {
          rows <- named[named$survey_observation == name, , drop = FALSE]
          if (any(.phone_obs_blank(rows$genus)) || any(.phone_obs_blank(rows$species))) {
            note("label '", name, "' is missing genus or species")
          }
          for (col in c("class", "order", "family", "common_name")) {
            known <- ! .phone_obs_blank(rows[[col]])
            if (any(known) && any(!known)) {
              note("label '", name, "' is missing ", col, " on ", sum(!known), " row(s)")
            }
          }
        }
        json_like <- grepl("^\\s*[\\[{]", named$survey_observation)
        if (any(json_like)) {
          note(sum(json_like), " label values are still raw JSON")
        }
      }
    }
  }

  # Media paths and files refer to each other.
  media_types <- c("phone-photo", "phone-video", "phone-audio")
  media_rows <- long[long$data_type %in% media_types, , drop = FALSE]
  paths <- as.character(media_rows$survey_observation)
  if (any(grepl("|", paths, fixed = TRUE))) {
    note("media values still join several files with '|'")
  }
  bad_prefix <- !is.na(paths) & nzchar(paths) & !startsWith(paths, "media/")
  if (any(bad_prefix)) {
    note(sum(bad_prefix), " media paths are not under media/")
  }
  referenced <- basename(paths[!is.na(paths) & nzchar(paths)])
  on_disk <- list.files(file.path(proc_dir, "media"))
  orphan_files <- setdiff(on_disk, referenced)
  missing_files <- setdiff(referenced, on_disk)
  if (length(orphan_files)) {
    note(
      length(orphan_files), " media files not referenced, e.g. ",
      paste(head(orphan_files, 5), collapse = ", ")
    )
  }
  if (length(missing_files)) {
    note(
      length(missing_files), " referenced media files missing on disk, e.g. ",
      paste(head(missing_files, 5), collapse = ", ")
    )
  }
  if (nrow(long) > 0L && any(!is.na(long$longitude))) {
    gpkg <- file.path(proc_dir, "observations.gpkg")
    if (!file.exists(gpkg)) {
      note("coordinates present but observations.gpkg is missing")
    }
  }
  problems
}

# Excel and the media JSON write whole numbers as 4.0; the CSV export writes 4.
# Compare the numeric value so the same observation is not counted twice.
.phone_obs_norm_value <- function(value, data_type) {
  value <- trimws(as.character(value))
  value[is.na(value)] <- ""
  numeric_row <- !is.na(data_type) & data_type == "numeric"
  parsed <- suppressWarnings(as.numeric(value))
  value[numeric_row & !is.na(parsed)] <- format(parsed[numeric_row & !is.na(parsed)], trim = TRUE, scientific = FALSE)
  value
}

.phone_obs_row_key <- function(df) {
  paste(
    df$feature_uuid,
    df$item_name,
    df$data_type,
    .phone_obs_norm_value(df$survey_observation, df$data_type),
    sep = "\r"
  )
}

test_that("downloaded exports reference every media file and every label tree", {
  root <- .phone_obs_export_root()
  skip_if(!dir.exists(root), paste("no export at", root))
  workbooks <- list.files(root, pattern = "^observations\\.xlsx$", recursive = TRUE, full.names = TRUE)
  workbooks <- workbooks[!grepl("/~\\$", workbooks)]
  skip_if(length(workbooks) == 0L, "export has no workbooks")

  problems <- unlist(lapply(dirname(workbooks), .phone_obs_audit_dir), use.names = FALSE)
  problems <- problems[!is.na(problems) & nzchar(problems)]

  # Known cases that previously failed.
  oiseaux <- workbooks[grepl("69_Oiseaux-Ivindo-Iron", workbooks)]
  if (length(oiseaux) == 1L) {
    long <- .phone_obs_read_sheet(oiseaux, "Long format")
    referenced <- any(grepl(
      "7708d584-1ebb-4ab2-8f67-6c6a4c00708d",
      long$survey_observation,
      fixed = TRUE
    ))
    if (!referenced) {
      problems <- c(problems, "Oiseaux photo 7708d584 is not referenced")
    }
  }
  nids <- workbooks[grepl("77_Nids-Ivindo", workbooks)]
  if (length(nids) == 1L) {
    long <- .phone_obs_read_sheet(nids, "Long format")
    row <- long[long$feature_uuid == "1f2cc777-d7ba-4e7e-8180-c79f381c9e47" &
                  long$data_type == "label", , drop = FALSE]
    if (nrow(row) != 1L || any(.phone_obs_blank(row$class)) ||
        !identical(row$species[[1]], "Pan troglodytes")) {
      problems <- c(
        problems,
        "Nids feature 1f2cc777 label is missing its taxonomic tree"
      )
    }
  }

  expect_equal(problems, character(), info = paste(problems, collapse = "\n"))
})

test_that("downloaded non-media rows cover a fresh API pull", {
  readRenviron("~/.Renviron")
  key <- Sys.getenv("PROTECTEDFAUNA_API_KEY")
  skip_if(!nzchar(key), "PROTECTEDFAUNA_API_KEY is not set")
  root <- .phone_obs_export_root()
  skip_if(!dir.exists(root), paste("no export at", root))

  hdr <- NatureCubeR::auth_headers(api_key = key)
  schema <- NatureCubeR::get_project_systems(hdr)
  systems <- NatureCubeR::list_systems(schema)
  csv_types <- c("choice", "text", "numeric", "label")
  workbooks <- list.files(root, pattern = "^observations\\.xlsx$", recursive = TRUE, full.names = TRUE)
  workbooks <- workbooks[!grepl("/~\\$", workbooks)]
  expect_gt(length(workbooks), 0L)

  problems <- character()
  for (xlsx in workbooks) {
    Sys.sleep(2)
    proc_dir <- dirname(xlsx)
    proc_id <- suppressWarnings(as.integer(sub("_.*$", "", basename(proc_dir))))
    if (is.na(proc_id)) {
      next
    }
    match <- systems[!is.na(systems$procedure_id) & systems$procedure_id == proc_id, , drop = FALSE]
    if (nrow(match) != 1L) {
      problems <- c(problems, paste0(basename(proc_dir), ": procedure id not in schema"))
      next
    }
    long <- .phone_obs_read_sheet(xlsx, "Long format")
    fetched <- lapply(csv_types, function(type) {
      last_error <- NULL
      for (attempt in seq_len(6L)) {
        page <- tryCatch(
          NatureCubeR:::.fetch_phone_obs_csv(
            hdr,
            project_id = schema$project_id,
            procedure_id = proc_id,
            data_type = type
          ),
          error = function(e) e
        )
        if (!inherits(page, "error")) {
          return(page)
        }
        last_error <- page
        if (!grepl("429", conditionMessage(page))) {
          stop(page)
        }
        Sys.sleep(10 * attempt)
      }
      stop(last_error)
    })
    combined <- NatureCubeR:::.bind_phone_obs_pages(fetched)
    api <- if (is.data.frame(combined) && nrow(combined) > 0L) {
      NatureCubeR:::.tidy_phone_observations(
        NatureCubeR:::.dedupe_phone_obs_rows(combined)
      )
    } else {
      tibble::tibble()
    }
    if (nrow(api) == 0L) {
      if (nrow(long) > 0L && any(long$data_type %in% csv_types)) {
        problems <- c(problems, paste0(basename(proc_dir), ": workbook has rows but the API returned none"))
      }
      next
    }
    api <- api[api$data_type %in% csv_types, , drop = FALSE]
    disk <- long[long$data_type %in% csv_types, , drop = FALSE]
    missing <- setdiff(.phone_obs_row_key(api), .phone_obs_row_key(disk))
    if (length(missing)) {
      problems <- c(
        problems,
        paste0(
          basename(proc_dir), ": ", length(missing),
          " API rows missing from the workbook, e.g. ",
          paste(head(gsub("\r", " | ", missing), 3), collapse = " ;; ")
        )
      )
    }
    for (type in csv_types) {
      api_n <- sum(api$data_type == type)
      disk_n <- sum(disk$data_type == type)
      if (disk_n < api_n) {
        problems <- c(
          problems,
          paste0(basename(proc_dir), ": ", type, " disk ", disk_n, " < api ", api_n)
        )
      }
    }
  }
  expect_equal(problems, character(), info = paste(problems, collapse = "\n"))
})
