test_that("a short page with a new cursor is not the last page", {
  step <- NatureCubeR:::.phone_obs_next_page(
    use_keyset = TRUE,
    next_observation_id = 5000L,
    n_rows = 151L,
    limit = 1000L,
    offset = 0L,
    total = 642L,
    seen_cursors = integer()
  )
  expect_false(step$done)
  expect_true(step$use_keyset)
  expect_identical(step$after_observation_id, 5000L)
})

test_that("a repeated cursor ends paging", {
  step <- NatureCubeR:::.phone_obs_next_page(
    use_keyset = TRUE,
    next_observation_id = 5000L,
    n_rows = 151L,
    limit = 1000L,
    offset = 0L,
    total = 642L,
    seen_cursors = 5000L
  )
  expect_true(step$done)
})

test_that("an empty page ends paging even when a cursor is present", {
  step <- NatureCubeR:::.phone_obs_next_page(
    use_keyset = TRUE,
    next_observation_id = 9000L,
    n_rows = 0L,
    limit = 1000L,
    offset = 0L,
    total = 642L,
    seen_cursors = integer()
  )
  expect_true(step$done)
})

test_that("without a cursor, offset continues until the reported total", {
  step <- NatureCubeR:::.phone_obs_next_page(
    use_keyset = TRUE,
    next_observation_id = NA_integer_,
    n_rows = 400L,
    limit = 1000L,
    offset = 0L,
    total = 1200L,
    seen_cursors = integer()
  )
  expect_false(step$done)
  expect_false(step$use_keyset)
  expect_identical(step$offset, 400L)

  done <- NatureCubeR:::.phone_obs_next_page(
    use_keyset = FALSE,
    next_observation_id = NA_integer_,
    n_rows = 800L,
    limit = 1000L,
    offset = 400L,
    total = 1200L,
    seen_cursors = integer()
  )
  expect_true(done$done)
})

test_that("a media observation with several files keeps every file", {
  raw <- tibble::tibble(
    feature_uuid = "f1",
    data_type = "phone-photo",
    item_name = "Photo",
    data = paste(
      "field_records/a/phone-photo/7708d584-1ebb-4ab2-8f67-6c6a4c00708d.jpg",
      "field_records/a/phone-photo/ed93605f-2d8f-4d3b-bb4d-056abfcd9b29.jpg",
      sep = " | "
    )
  )
  tidy <- NatureCubeR:::.tidy_phone_observations(raw)
  expect_equal(nrow(tidy), 2L)
  expect_equal(
    sort(tidy$survey_observation),
    sort(c(
      "media/7708d584-1ebb-4ab2-8f67-6c6a4c00708d.jpg",
      "media/ed93605f-2d8f-4d3b-bb4d-056abfcd9b29.jpg"
    ))
  )
})

test_that("a bare scientific name borrows taxonomy from the same label", {
  raw <- tibble::tibble(
    feature_uuid = c("full", "bare"),
    data_type = c("label", "label"),
    item_name = "Taxonomic label",
    data = c(
      "Pan troglodytes",
      "Pan troglodytes"
    ),
    labels = c(
      jsonlite::toJSON(list(list(
        class_ = "Mammalia",
        order = "Primates",
        family = "Hominidae",
        genus = "Pan",
        species = "Pan troglodytes",
        common_name = "Chimpanzee",
        label = "Pan troglodytes"
      )), auto_unbox = FALSE),
      NA_character_
    )
  )
  tidy <- NatureCubeR:::.tidy_phone_observations(raw)
  bare <- tidy[tidy$feature_uuid == "bare", , drop = FALSE]
  expect_equal(bare$survey_observation, "Pan troglodytes")
  expect_equal(bare$class, "Mammalia")
  expect_equal(bare$order, "Primates")
  expect_equal(bare$family, "Hominidae")
  expect_equal(bare$genus, "Pan")
  expect_equal(bare$species, "Pan troglodytes")
  expect_equal(bare$common_name, "Chimpanzee")
})

test_that("protected fauna loop downloads every phone-audio row", {
  readRenviron("~/.Renviron")
  key <- Sys.getenv("PROTECTEDFAUNA_API_KEY")
  skip_if(!nzchar(key), "PROTECTEDFAUNA_API_KEY is not set")

  hdr <- NatureCubeR::auth_headers(api_key = key)
  schema <- NatureCubeR::get_project_systems(hdr)
  systems <- NatureCubeR::list_systems(schema)
  # Same walk as the project loop: every procedure that has an id.
  proc_row <- systems[!is.na(systems$procedure_id) &
                        systems$procedure_name == "Oiseaux Ivindo Iron", , drop = FALSE]
  expect_equal(nrow(proc_row), 1L)

  procedure <- NatureCubeR::get_procedure(
    schema,
    system_name = proc_row$system_name[[1]],
    procedure_name = proc_row$procedure_name[[1]]
  )
  expect_true("phone-audio" %in% procedure$items$data_type)

  header <- NatureCubeR:::.phone_obs_request(
    hdr, procedure$project_id, procedure$procedure_id, "phone-audio",
    limit = 1L, offset = 0L
  )
  announced <- NatureCubeR:::.perform_phone_obs_request(
    header, "phone-audio", procedure$project_id, procedure$procedure_id
  )
  expect_false(isTRUE(announced$empty))
  announced_total <- NatureCubeR:::.phone_obs_page_meta(announced$resp)$total
  expect_gt(announced_total, 1L)

  dest <- tempfile("phone-obs-audio-")
  dir.create(dest)
  on.exit(unlink(dest, recursive = TRUE), add = TRUE)
  result <- NatureCubeR::get_phone_observations(
    hdr, procedure,
    data_type = "phone-audio",
    dest_dir = dest
  )
  fetched <- result$by_type$rows[result$by_type$data_type == "phone-audio"]
  expect_gte(fetched, announced_total)
  expect_gte(result$media_count, 1L)
  expect_true(file.exists(result$excel_path))
})
