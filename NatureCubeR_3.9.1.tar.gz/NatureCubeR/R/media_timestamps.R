# Internal function used to chunk media metadata
send_media_chunks <- function(hdr, datachunk) {
  datachunk <- jsonlite::toJSON(datachunk, pretty = TRUE)

  urlreq_ap <- httr2::req_url_path_append(hdr$root, "updateTimestamps", hdr$key)
  urlreq_ap <- urlreq_ap %>% httr2::req_method("PUT") %>% httr2::req_body_json(jsonlite::fromJSON(datachunk))
  preq <- httr2::req_perform(urlreq_ap, verbosity = 3)
  resp <- httr2::resp_body_string(preq)

  return(jsonlite::fromJSON(resp))
}


#' @title Update timestamps for multiple media records
#'
#' @description
#' Updates timestamps for one or more media records in a single API call.
#' For large datasets (>1000 records), use \link{push_new_timestamps} instead.
#'
#' @param hdr A base URL provided and valid API key returned by the
#'   function \link{auth_headers}
#' @param media_records A data frame or tibble containing the media records to update.
#'   Must contain the following columns:
#'   \itemize{
#'     \item \strong{media_file_record_id} (required): Numeric. The unique identifier
#'           of the media file record to update.
#'     \item \strong{new_timestamp} (required): Character. The new timestamp in
#'           ISO 8601 format (e.g., "2024-01-15T10:30:00" or "2024-01-15 10:30:00").
#'   }
#'   Additional columns will be ignored.
#'
#' @return A list containing the API response with update status
#'
#' @examples
#' \dontrun{
#'   # Create a data frame with media records to update
#'   updates <- data.frame(
#'     media_file_record_id = c(123, 456, 789),
#'     new_timestamp = c(
#'       "2024-01-15T10:30:00",
#'       "2024-01-15T14:20:00",
#'       "2024-01-15T18:45:00"
#'     )
#'   )
#'   
#'   # Update the timestamps
#'   result <- update_media_timestamps(headers, updates)
#'   
#'   # Using tibble format
#'   library(tibble)
#'   updates <- tibble(
#'     media_file_record_id = c(123, 456),
#'     new_timestamp = c("2024-01-15T10:30:00", "2024-01-15T14:20:00")
#'   )
#'   result <- update_media_timestamps(headers, updates)
#' }
#'
#' @seealso
#' \link{push_new_timestamps} for automatic chunking of large datasets
#'
#' @author
#' Adam Varley
#' @export
update_media_timestamps <- function(hdr, media_records) {
  # Validate required columns
  required_cols <- c("media_file_record_id", "new_timestamp")
  missing_cols <- setdiff(required_cols, names(media_records))

  if (length(missing_cols) > 0) {
    stop("Missing required columns: ", paste(missing_cols, collapse = ", "))
  }

  # Validate data types
  if (!is.numeric(media_records$media_file_record_id)) {
    stop("media_file_record_id must be numeric")
  }
  if (any(is.na(media_records$media_file_record_id))) {
    stop("media_file_record_id cannot contain NA values")
  }
  if (any(media_records$media_file_record_id <= 0)) {
    stop("media_file_record_id must be positive")
  }
  if (any(media_records$media_file_record_id %% 1 != 0)) {
    stop("media_file_record_id must be an integer")
  }

  if (!is.character(media_records$new_timestamp)) {
    stop("new_timestamp must be character string in ISO 8601 format")
  }

  # Basic ISO 8601 format validation for new_timestamp
  # Accepts patterns like: 2024-01-31T23:59:59Z or 2024-01-31T23:59:59+01:00
  iso8601_pattern <- "^\\d{4}-\\d{2}-\\d{2}T\\d{2}:\\d{2}:\\d{2}(Z|[+-]\\d{2}:?\\d{2})?$"
  invalid_idx <- which(!is.na(media_records$new_timestamp) &
                         !grepl(iso8601_pattern, media_records$new_timestamp))
  if (length(invalid_idx) > 0) {
    stop(
      "new_timestamp must be in ISO 8601 format, e.g. '2024-01-31T23:59:59Z'. ",
      "Invalid values at row(s): ",
      paste(invalid_idx, collapse = ", ")
    )
  }

  # Select only required columns
  media_records <- media_records[, required_cols, drop = FALSE]

  # Make API request
  urlreq_ap <- httr2::req_url_path_append(hdr$root, "updateTimestamps", hdr$key) %>%
    httr2::req_method("PUT") %>%
    httr2::req_body_json(media_records)

  preq <- tryCatch(
    httr2::req_perform(urlreq_ap),
    error = function(e) {
      stop(
        "Failed to perform request to update media timestamps: ",
        conditionMessage(e),
        call. = FALSE
      )
    }
  )
  resp <- httr2::resp_body_string(preq)

  result <- jsonlite::fromJSON(resp)

  message("Successfully updated ", nrow(media_records), " media timestamp(s)")

  return(result)
}


#' @title Push new timestamps to the platform in chunks
#'
#' @description
#' Updates timestamps for many media records by splitting them into chunks,
#' avoiding timeouts on large datasets. For small datasets, use
#' \link{update_media_timestamps} directly.
#'
#' @param hdr A base URL provided and valid API key returned by the
#'   function \link{auth_headers}
#' @param media_metadata A data frame or tibble containing the media records to update.
#'   Must contain the following columns:
#'   \itemize{
#'     \item \strong{media_file_record_id} (required): Numeric. The unique identifier
#'           of the media file record to update.
#'     \item \strong{new_timestamp} (required): Character. The new timestamp in
#'           ISO 8601 format (e.g., "2024-01-15T10:30:00" or "2024-01-15 10:30:00").
#'   }
#'   Additional columns will be ignored during submission.
#' @param chunksize An integer specifying the number of records to submit per
#'   chunk. Recommended values: 50-200 depending on network conditions. If
#'   chunksize exceeds the number of rows, it will be automatically adjusted.
#'
#' @return No explicit return value. A progress bar tracks records submitted
#'   across all chunks.
#'
#' @examples
#' \dontrun{
#'   # Create a large dataset with timestamp updates
#'   updates <- data.frame(
#'     media_file_record_id = 1:1000,
#'     new_timestamp = seq(
#'       as.POSIXct("2024-01-15 08:00:00"),
#'       by = "30 sec",
#'       length.out = 1000
#'     ) %>% format("%Y-%m-%dT%H:%M:%S")
#'   )
#'   
#'   # Push updates in chunks of 100
#'   push_new_timestamps(headers, updates, chunksize = 100)
#'   
#'   # Using tibble format
#'   library(tibble)
#'   updates <- tibble(
#'     media_file_record_id = c(123, 456, 789),
#'     new_timestamp = c(
#'       "2024-01-15T10:30:00",
#'       "2024-01-15T14:20:00",
#'       "2024-01-15T18:45:00"
#'     )
#'   )
#'   push_new_timestamps(headers, updates, chunksize = 50)
#' }
#'
#' @seealso
#' \link{update_media_timestamps} for direct submission without chunking
#'
#' @author
#' Adam Varley, Cristobal Salamé
#' @export
push_new_timestamps <- function(hdr, media_metadata, chunksize) {
  # Validate required columns up front, so a mistake (e.g. forgetting to
  # join in media_file_record_id before calling this) fails immediately with
  # a clear message instead of surfacing as a 422 from the API partway
  # through a chunked upload.
  required_cols <- c("media_file_record_id", "new_timestamp")
  missing_cols <- setdiff(required_cols, names(media_metadata))
  if (length(missing_cols) > 0) {
    stop(
      "media_metadata is missing required column(s): ", paste(missing_cols, collapse = ", "),
      ". Use get_media_assets() to get media_file_record_id.",
      call. = FALSE
    )
  }

  if (anyNA(media_metadata$media_file_record_id)) {
    stop("media_file_record_id cannot contain NA values", call. = FALSE)
  }
  if (anyNA(media_metadata$new_timestamp)) {
    stop("new_timestamp cannot contain NA values", call. = FALSE)
  }

  # Additional columns are not submitted
  media_metadata <- media_metadata[, required_cols, drop = FALSE]

  if (chunksize > nrow(media_metadata)) {
    stop('chunksize is bigger than length of data', call. = FALSE)
  }

  spl.dt <- split(media_metadata, cut(seq_len(nrow(media_metadata)), round(nrow(media_metadata) / chunksize)))

  pb <- cli::cli_progress_bar(
    format = "Submitting {cli::pb_current}/{cli::pb_total} timestamp(s) | {cli::pb_bar} {cli::pb_percent} | ETA: {cli::pb_eta}",
    total  = nrow(media_metadata),
    clear  = FALSE
  )
  # on.exit (not tryCatch) so the bar is always closed - including on a user
  # interrupt (e.g. Escape/Ctrl+C) - see .check_label_values() in
  # push_phone_observations.R for the same pattern and why tryCatch's `error`
  # handler alone isn't enough.
  on.exit(cli::cli_progress_done(id = pb), add = TRUE)

  submitted <- 0
  for (i in seq_along(spl.dt)) {
    send_media_chunks(hdr, spl.dt[[i]])
    submitted <- submitted + nrow(spl.dt[[i]])
    cli::cli_progress_update(id = pb, set = submitted)
  }
}


#' @title Sequentially correct timestamps for a single device
#'
#' @description
#' Internal helper called by \link{correct_timestamps}. Chains corrected
#' timestamps row-by-row for one device (pre-sorted by \code{file_name}, with
#' \code{is_outlier} already computed): good files keep their timestamp, a bad
#' first file is anchored to \code{installation_timestamp}, and each
#' subsequent bad run is anchored to the last good time (+1 minute) then
#' offset by the original inter-file gaps.
#'
#' @param media_metadata A data frame for a single device, sorted by
#'   \code{file_name}, containing at minimum the columns \code{timestamp}
#'   (POSIXct), \code{installation_timestamp} (POSIXct or Date), and
#'   \code{is_outlier} (logical).
#'
#' @return The input data frame with two additional columns:
#'   \itemize{
#'     \item \strong{new_timestamp}: POSIXct. The corrected timestamp.
#'     \item \strong{correction_type}: Character. One of \code{"none"},
#'       \code{"initial_run"}, \code{"mid_deployment_first"}, or
#'       \code{"mid_deployment_chain"}.
#'   }
#'
#' @seealso \link{correct_timestamps}
#'
#' @author
#' Cristobal Salamé
#' @keywords internal
.correct_device_timestamps <- function(media_metadata) {
  n          <- nrow(media_metadata)
  ts         <- media_metadata$timestamp
  is_outlier <- media_metadata$is_outlier

  tz_orig <- attr(ts, "tzone")
  if (is.null(tz_orig) || nchar(tz_orig) == 0) tz_orig <- "UTC"

  new_timestamp       <- lubridate::as_datetime(rep(NA_real_, n), tz = tz_orig)
  correction_type <- character(n)
  install_ts      <- lubridate::as_datetime(media_metadata$installation_timestamp[1])
  gap_secs        <- c(NA_real_, as.numeric(diff(ts), units = "secs"))

  for (i in seq_len(n)) {
    if (!is_outlier[i]) {
      # Good timestamp: preserve as-is
      new_timestamp[i]   <- ts[i]
      correction_type[i] <- "none"
    } else if (i == 1) {
      # is_outlier[i] is TRUE here (the preceding `if` already handled the
      # FALSE case), so this only fires when the first file on the device
      # is genuinely bad: anchor to installation timestamp
      new_timestamp[i]   <- install_ts
      correction_type[i] <- "initial_run"
    } else if (!is_outlier[i - 1]) {
      # First bad file after a run of good files (mid-deployment reset):
      # use the last good corrected timestamp + 1 minute
      new_timestamp[i]   <- new_timestamp[i - 1] + 60
      correction_type[i] <- "mid_deployment_first"
    } else {
      # Continuation of a bad run: preserve the original inter-file gap
      new_timestamp[i]   <- new_timestamp[i - 1] + gap_secs[i]
      correction_type[i] <- "mid_deployment_chain"
    }
  }

  media_metadata$new_timestamp   <- new_timestamp
  media_metadata$correction_type <- correction_type
  media_metadata
}


#' @title Correct camera trap timestamps
#'
#' @description
#' Identifies and corrects media timestamps corrupted by a camera clock reset
#' (e.g. the clock reverts to a fixed "bad year" after a battery failure).
#' Handles both a reset at the start of a deployment (first file anchored to
#' \code{installation_timestamp}) and a reset partway through (anchored to the
#' last known-good timestamp), preserving the camera's original inter-file
#' gaps in both cases.
#'
#' Outlier detection uses a 48-hour buffer on both deployment bounds: a file
#' is flagged if its \code{timestamp} falls more than 48 hours before
#' \code{installation_timestamp} or more than 48 hours after
#' \code{removal_timestamp}.
#'
#' @param media_metadata A data frame or tibble containing, at minimum, the
#'   following columns:
#'   \itemize{
#'     \item \strong{file_name}: Character. File name of each media file,
#'           used to sort files in chronological order within each device.
#'           Must be unique within each \code{device_id}; the function stops
#'           with an error if any duplicates are found.
#'     \item \strong{device_id}: Character. Unique camera identifier for each
#'           file.
#'     \item \strong{timestamp}: POSIXct, or character/Date coercible via
#'           \link[lubridate]{as_datetime}. Timestamp read from the file's
#'           EXIF metadata.
#'     \item \strong{installation_timestamp}: POSIXct, or character/Date
#'           coercible via \link[lubridate]{as_datetime}, giving the
#'           date/time the camera was deployed in the field (typically one
#'           repeated value per device).
#'     \item \strong{removal_timestamp}: POSIXct, or character/Date coercible
#'           via \link[lubridate]{as_datetime}, giving the date/time the
#'           camera was removed from the field.
#'   }
#'
#' @return A tibble with the input columns (\code{file_name}, \code{device_id},
#'   \code{timestamp}, \code{installation_timestamp}, \code{removal_timestamp})
#'   and three additional columns produced by the function:
#'   \itemize{
#'     \item \strong{is_outlier}: Logical. \code{TRUE} for files whose
#'           timestamp was identified as incorrect.
#'     \item \strong{new_timestamp}: POSIXct. The corrected timestamp.
#'           Equals \code{timestamp} for non-outlier files.
#'     \item \strong{correction_type}: Character. One of:
#'       \describe{
#'         \item{\code{"none"}}{Timestamp was valid; no correction applied.}
#'         \item{\code{"initial_run"}}{First file on device was bad; anchored
#'           to \code{installation_timestamp}.}
#'         \item{\code{"mid_deployment_first"}}{First bad file after a run of
#'           good files; anchored to last good timestamp + 1 minute.}
#'         \item{\code{"mid_deployment_chain"}}{Subsequent bad file in a run;
#'           offset from the previous corrected timestamp by the original
#'           inter-file time gap.}
#'       }
#'   }
#'
#' @examples
#' \dontrun{
#'   library(dplyr)
#'   library(readr)
#'
#'   cam_data <- read_csv("cam_timestamp.csv") %>%
#'     left_join(deployments, by = "device_id")
#'
#'   corrected <- correct_timestamps(cam_data)
#'
#'   # Inspect corrections
#'   corrected %>%
#'     filter(is_outlier) %>%
#'     select(device_id, file_name, new_timestamp, correction_type)
#'
#'   # Prepare for platform upload
#'   to_upload <- corrected %>%
#'     filter(is_outlier) %>%
#'     mutate(new_timestamp = format(new_timestamp, "%Y-%m-%dT%H:%M:%S")) %>%
#'     select(media_file_record_id, new_timestamp)
#'
#'   push_new_timestamps(headers, to_upload, chunksize = 100)
#' }
#'
#' @seealso
#' \link{push_new_timestamps} to upload corrected timestamps to the platform
#'
#' @author
#' Cristobal Salamé
#' @export
correct_timestamps <- function(media_metadata) {

  required_cols <- c("file_name", "device_id", "timestamp", "installation_timestamp", "removal_timestamp")
  missing_cols  <- setdiff(required_cols, names(media_metadata))

  if (length(missing_cols) > 0) {
    stop("Data frame is missing required column(s): ", paste(missing_cols, collapse = ", "))
  }

  media_metadata <- media_metadata %>%
    dplyr::mutate(
      timestamp = lubridate::as_datetime(.data$timestamp),
      installation_timestamp = lubridate::as_datetime(.data$installation_timestamp),
      removal_timestamp = lubridate::as_datetime(.data$removal_timestamp)
    )

  # --- Check for missing values (also catches timestamps that failed to
  # parse above, since as_datetime() turns those into NA) ---
  cols_with_na <- names(media_metadata)[sapply(media_metadata, anyNA)]
  if (length(cols_with_na) > 0) {
    stop(
      "The following column(s) contain missing values, please check the data: ",
      paste(cols_with_na, collapse = ", ")
    )
  }

  # --- file_name must be unique within each device_id ---
  dup_idx <- duplicated(media_metadata[c("device_id", "file_name")])
  if (any(dup_idx)) {
    stop(
      "file_name must be unique within each device_id. Duplicate(s) found: ",
      paste(
        unique(paste0(media_metadata$device_id[dup_idx], "/", media_metadata$file_name[dup_idx])),
        collapse = ", "
      )
    )
  }

  # --- Outlier detection: 48-hour buffer around deployment bounds ---
  media_metadata$is_outlier <- (media_metadata$timestamp + lubridate::hours(48) < media_metadata$installation_timestamp) |
                               (media_metadata$timestamp - lubridate::hours(48) > media_metadata$removal_timestamp)

  # --- Sequential correction: sort by device/file, then chain per device ---
  media_metadata %>%
    dplyr::arrange(.data$device_id, .data$file_name) %>%
    dplyr::group_by(.data$device_id) %>%
    dplyr::group_modify(~ .correct_device_timestamps(.x)) %>%
    dplyr::ungroup()
}
