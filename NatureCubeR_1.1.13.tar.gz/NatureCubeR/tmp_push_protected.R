# Push Donnée pour Application_2.xlsx to the Protected Fauna project.
# Long-format phone export -> wide format -> validate -> upload.

readRenviron("~/.Renviron")
devtools::load_all(".", quiet = TRUE)

api_key <- Sys.getenv("PROTECTEDFAUNA_API_KEY")
if (!nzchar(api_key)) {
  stop("PROTECTEDFAUNA_API_KEY is not set in the environment / ~/.Renviron")
}

xlsx_path <- "tmp_protected_data.xlsx"
if (!file.exists(xlsx_path)) {
  src <- list.files(path.expand("~/Downloads"), pattern = "Application_2\\.xlsx$", full.names = TRUE)[1]
  if (is.na(src) || !nzchar(src)) stop("Could not find Application_2.xlsx in Downloads")
  file.copy(src, xlsx_path, overwrite = TRUE)
}

protected_data <- readxl::read_excel(xlsx_path)

# Excel export names -> NatureCube project schema names
system_map <- c(
  "Plante Ivindo" = "Plante Ivindo",
  "Mammifere Ivindo" = "Mammifères Ivindo Iron"
)
procedure_map <- list(
  "Plante Ivindo" = c("Arbre" = "Arbre"),
  "Mammifere Ivindo" = c(
    "Crotte" = "Crotte Ivindo 3",
    "Empreinte" = "Empreinte Ivindo",
    "Nid" = "Nids Ivindo",
    "Terrier" = "Terrier",
    "activité hu" = "Humain Ivindo"
  )
)

hdr <- auth_headers(api_key)
project_systems <- get_project_systems(hdr)

# Pivot one system/procedure chunk from long (item rows) to wide (one row per feature).
.pivot_phone_long <- function(chunk, procedure) {
  items <- procedure$items
  label_name <- items$item_name[items$data_type == "label"][1]
  text_name <- items$item_name[items$data_type == "text"][1]
  if (is.na(label_name) || !nzchar(label_name)) {
    stop("No label item found in procedure ", procedure$procedure_name)
  }
  if (is.na(text_name) || !nzchar(text_name)) {
    stop("No text item found in procedure ", procedure$procedure_name)
  }

  chunk$longitude <- as.numeric(chunk$longitude)
  chunk$latitude <- as.numeric(chunk$latitude)
  chunk$timestamp <- as.POSIXct(chunk$timestamp, tz = "UTC")

  # Prefer item_name when present; otherwise map observation_type.
  chunk$col <- dplyr::case_when(
    !is.na(chunk$item_name) & nzchar(as.character(chunk$item_name)) ~ as.character(chunk$item_name),
    chunk$observation_type == "label" ~ label_name,
    chunk$observation_type == "text" ~ text_name,
    TRUE ~ NA_character_
  )
  chunk <- chunk[!is.na(chunk$col), , drop = FALSE]
  if (nrow(chunk) == 0L) {
    return(tibble::tibble())
  }

  keys <- c("longitude", "latitude", "timestamp")
  wide <- chunk %>%
    dplyr::select(dplyr::all_of(keys), col, data) %>%
    dplyr::group_by(dplyr::across(dplyr::all_of(c(keys, "col")))) %>%
    dplyr::summarise(data = dplyr::first(data[!is.na(data)]), .groups = "drop") %>%
    tidyr::pivot_wider(names_from = col, values_from = data)

  # Ensure expected columns exist even if a type was missing for all rows.
  if (!(label_name %in% names(wide))) wide[[label_name]] <- NA_character_
  if (!(text_name %in% names(wide))) wide[[text_name]] <- NA_character_

  wide
}

pairs <- unique(as.data.frame(protected_data[, c("system_name", "procedure_name")]))
pairs <- pairs[!is.na(pairs$system_name) & !is.na(pairs$procedure_name), , drop = FALSE]

all_results <- list()

for (i in seq_len(nrow(pairs))) {
  excel_sys <- as.character(pairs$system_name[[i]])
  excel_proc <- as.character(pairs$procedure_name[[i]])

  api_sys <- unname(system_map[[excel_sys]])
  api_proc <- if (!is.null(procedure_map[[excel_sys]])) {
    unname(procedure_map[[excel_sys]][[excel_proc]])
  } else {
    NULL
  }

  cat("\n==========\n")
  cat("Excel:", excel_sys, "/", excel_proc, "\n")
  if (is.null(api_sys) || is.null(api_proc) || !nzchar(api_proc)) {
    cat("SKIP: no mapping to API system/procedure\n")
    next
  }
  cat("API:  ", api_sys, "/", api_proc, "\n")

  procedure <- get_procedure(
    project_systems,
    system_name = api_sys,
    procedure_name = api_proc
  )

  chunk <- protected_data[
    protected_data$system_name == excel_sys &
      protected_data$procedure_name == excel_proc,
    ,
    drop = FALSE
  ]
  wide <- .pivot_phone_long(chunk, procedure)
  cat("Wide rows:", nrow(wide), " cols:", paste(names(wide), collapse = ", "), "\n")
  if (nrow(wide) == 0L) {
    cat("SKIP: no rows after pivot\n")
    next
  }

  validated <- validate_csv_against_procedure(
    procedure = procedure,
    observation_data = wide,
    hdr = hdr
  )
  n_ok <- sum(validated$status == "success", na.rm = TRUE)
  n_bad <- sum(validated$status != "success", na.rm = TRUE)
  cat("Validated: success=", n_ok, " rejected=", n_bad, "\n")
  if (n_bad > 0) {
    bad <- validated[validated$status != "success", c("status", "message"), drop = FALSE]
    print(utils::head(as.data.frame(bad), 10))
  }
  if (n_ok == 0L) {
    cat("SKIP upload: nothing passed validation\n")
    all_results[[paste(excel_sys, excel_proc, sep = "/")]] <- list(
      validated = validated,
      upload = NULL
    )
    next
  }

  upload_result <- upload_observations_from_csv(
    hdr = hdr,
    validated = validated,
    dry_run = FALSE
  )
  cat("Upload done.\n")
  print(upload_result$result)
  all_results[[paste(excel_sys, excel_proc, sep = "/")]] <- list(
    validated = validated,
    upload = upload_result
  )
}

cat("\nFinished all procedure groups.\n")
invisible(all_results)
